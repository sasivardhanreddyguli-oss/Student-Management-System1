# CampusDesk – Student Management System

A responsive full-stack student directory application built with HTML, CSS, JavaScript, Node.js, Express and MongoDB.

## Features
- Add student records with name, email, course, year and optional phone number.
- Edit existing student records.
- Delete student records.
- Search by student name, email or course.
- Filter records by course.
- Dashboard cards for student, course and academic-year counts.
- Responsive table and mobile card layout.
- Server-side validation and duplicate-email handling.
- MongoDB persistence through Mongoose.

## Requirements
- Node.js 18 or later
- npm
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Run locally
1. Extract this project folder.
2. Open a terminal in the project directory.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Set `MONGO_URI` in `.env` to your local MongoDB URL or your MongoDB Atlas connection string.
6. Start the application:
   ```bash
   npm start
   ```
7. Open http://localhost:3000.

For development with automatic restarts, use `npm run dev`.

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/students` | List all students |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/:id` | Update a student |
| DELETE | `/api/students/:id` | Delete a student |

## Project structure
```text
Student_Management_System/
├── models/
│   └── Student.js
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Database schema
The `Student` collection stores:
- `name` – required student name
- `email` – required, unique email address
- `course` – required course
- `year` – required academic year (1–6)
- `phone` – optional phone number
- `createdAt` and `updatedAt` – timestamps

## Notes
This is an educational project starter. It does not include authentication, role-based access, deployment or production security hardening. Configure your own MongoDB connection and test the application before submitting. Never commit your `.env` file or database credentials to GitHub.
