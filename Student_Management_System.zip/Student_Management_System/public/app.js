const tableBody = document.getElementById("studentTable");
const mobileList = document.getElementById("mobileList");
const form = document.getElementById("studentForm");
const modal = document.getElementById("modalBackdrop");
const messageBox = document.getElementById("message");
let students = [];
let editingId = null;

const initials = (name) => name.split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
const escapeHtml = (value = "") => String(value).replace(/[&<>"']/g, char => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[char]));

function showMessage(message, isError = false) {
  messageBox.textContent = message;
  messageBox.className = isError ? "message error" : "message";
  if (message) setTimeout(() => { messageBox.textContent = ""; }, 4500);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

async function loadStudents() {
  try {
    students = await api("/api/students");
    renderStudents();
  } catch (error) {
    tableBody.innerHTML = `<tr><td colspan="6" class="empty">${escapeHtml(error.message)} Check your server and MongoDB connection.</td></tr>`;
    showMessage(error.message, true);
  }
}

function renderStudents() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const course = document.getElementById("courseFilter").value;
  const filtered = students.filter(student => {
    const matchesQuery = [student.name, student.email, student.course].some(value => value.toLowerCase().includes(query));
    return matchesQuery && (!course || student.course === course);
  });

  document.getElementById("totalStudents").textContent = students.length;
  document.getElementById("totalCourses").textContent = new Set(students.map(s => s.course)).size;
  document.getElementById("totalYears").textContent = new Set(students.map(s => s.year)).size;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${students.length} students`;

  const filter = document.getElementById("courseFilter");
  const selected = filter.value;
  const courses = [...new Set(students.map(s => s.course))].sort();
  filter.innerHTML = `<option value="">All courses</option>` + courses.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join("");
  filter.value = courses.includes(selected) ? selected : "";

  if (!filtered.length) {
    tableBody.innerHTML = `<tr><td colspan="6" class="empty">No matching student records found.</td></tr>`;
    mobileList.innerHTML = `<div class="empty">No matching student records found.</div>`;
    return;
  }

  tableBody.innerHTML = filtered.map(s => `
    <tr>
      <td><div class="student-name"><span class="student-avatar">${escapeHtml(initials(s.name))}</span>${escapeHtml(s.name)}</div></td>
      <td><span class="course-tag">${escapeHtml(s.course)}</span></td>
      <td><span class="year-tag">Year ${Number(s.year)}</span></td>
      <td>${escapeHtml(s.phone || "—")}</td>
      <td>${escapeHtml(s.email)}</td>
      <td><div class="action-group"><button class="action-btn" data-edit="${s._id}">Edit</button><button class="action-btn delete" data-delete="${s._id}">Delete</button></div></td>
    </tr>`).join("");

  mobileList.innerHTML = filtered.map(s => `
    <article class="student-card">
      <div class="student-card-top"><div class="student-name"><span class="student-avatar">${escapeHtml(initials(s.name))}</span>${escapeHtml(s.name)}</div><span class="course-tag">${escapeHtml(s.course)}</span></div>
      <p class="student-card-meta">Year ${Number(s.year)} · ${escapeHtml(s.phone || "No phone added")}</p>
      <div class="student-card-email">${escapeHtml(s.email)}</div>
      <div class="action-group"><button class="action-btn" data-edit="${s._id}">Edit</button><button class="action-btn delete" data-delete="${s._id}">Delete</button></div>
    </article>`).join("");
}

function openModal(student = null) {
  editingId = student?._id || null;
  form.reset();
  document.getElementById("modalTitle").textContent = student ? "Edit student" : "Add a student";
  document.getElementById("saveBtn").textContent = student ? "Update student" : "Save student";
  if (student) {
    for (const key of ["name", "email", "course", "year", "phone"]) form.elements[key].value = student[key] ?? "";
  }
  modal.hidden = false;
  document.getElementById("name").focus();
}
function closeModal() { modal.hidden = true; editingId = null; }

document.getElementById("addStudentBtn").addEventListener("click", () => openModal());
document.getElementById("closeModal").addEventListener("click", closeModal);
document.getElementById("cancelModal").addEventListener("click", closeModal);
modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !modal.hidden) closeModal(); });
document.getElementById("searchInput").addEventListener("input", renderStudents);
document.getElementById("courseFilter").addEventListener("change", renderStudents);

form.addEventListener("submit", async event => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(form).entries());
  payload.year = Number(payload.year);
  try {
    await api(editingId ? `/api/students/${editingId}` : "/api/students", {
      method: editingId ? "PUT" : "POST",
      body: JSON.stringify(payload)
    });
    closeModal();
    showMessage(editingId ? "Student updated successfully." : "Student added successfully.");
    await loadStudents();
  } catch (error) { showMessage(error.message, true); }
});

document.addEventListener("click", async event => {
  const editButton = event.target.closest("[data-edit]");
  const deleteButton = event.target.closest("[data-delete]");
  if (editButton) {
    const student = students.find(s => s._id === editButton.dataset.edit);
    if (student) openModal(student);
  }
  if (deleteButton) {
    const id = deleteButton.dataset.delete;
    const student = students.find(s => s._id === id);
    if (!student || !confirm(`Delete the record for ${student.name}?`)) return;
    try {
      await api(`/api/students/${id}`, { method: "DELETE" });
      showMessage("Student deleted successfully.");
      await loadStudents();
    } catch (error) { showMessage(error.message, true); }
  }
});

loadStudents();
