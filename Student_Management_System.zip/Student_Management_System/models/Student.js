const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  course: { type: String, required: true, trim: true },
  year: { type: Number, required: true, min: 1, max: 6 },
  phone: { type: String, trim: true, default: "" }
}, { timestamps: true });

module.exports = mongoose.model("Student", studentSchema);
