require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const Student = require("./models/Student");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/student_management")
  .then(() => console.log("Connected to MongoDB"))
  .catch((error) => {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  });

function validateStudent(data) {
  const { name, email, course, year } = data;
  if (!name || !email || !course || !year) return "Please fill in all required fields.";
  if (!/^\S+@\S+\.\S+$/.test(email)) return "Please enter a valid email address.";
  if (!Number.isInteger(Number(year)) || Number(year) < 1 || Number(year) > 6) {
    return "Year must be a number between 1 and 6.";
  }
  return null;
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Student Management API is running" });
});

app.get("/api/students", async (req, res) => {
  try {
    const students = await Student.find().sort({ createdAt: -1 });
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: "Could not load students." });
  }
});

app.post("/api/students", async (req, res) => {
  const validationError = validateStudent(req.body);
  if (validationError) return res.status(400).json({ message: validationError });

  try {
    const student = await Student.create({
      name: req.body.name.trim(),
      email: req.body.email.trim().toLowerCase(),
      course: req.body.course.trim(),
      year: Number(req.body.year),
      phone: (req.body.phone || "").trim()
    });
    res.status(201).json(student);
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "A student with this email already exists." });
    res.status(500).json({ message: "Could not add student." });
  }
});

app.put("/api/students/:id", async (req, res) => {
  const validationError = validateStudent(req.body);
  if (validationError) return res.status(400).json({ message: validationError });

  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      {
        name: req.body.name.trim(),
        email: req.body.email.trim().toLowerCase(),
        course: req.body.course.trim(),
        year: Number(req.body.year),
        phone: (req.body.phone || "").trim()
      },
      { new: true, runValidators: true }
    );
    if (!student) return res.status(404).json({ message: "Student not found." });
    res.json(student);
  } catch (error) {
    if (error.code === 11000) return res.status(409).json({ message: "A student with this email already exists." });
    res.status(500).json({ message: "Could not update student." });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found." });
    res.json({ message: "Student deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Could not delete student." });
  }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
